netstat -an | grep "ESTABLISHED"
