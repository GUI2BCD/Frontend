curl ifconfig.me 2>&1 
