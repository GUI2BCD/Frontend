traceroute -q1 www.google.com 2>&1
