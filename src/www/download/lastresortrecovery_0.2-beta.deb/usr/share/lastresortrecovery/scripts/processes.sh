ps aux | grep `whoami` 
